# Publicação autorizada: somente site e APK

O proprietário autorizou disponibilizar o site e o APK Debug de teste no repositório público lottan-lit/ODMANI-SoftUI-2.0. A visibilidade do repositório não foi alterada.

As fontes Android atualizadas e os registros detalhados de validação não fazem parte desta publicação. O diretório android/ permanece na versão de origem; não deve ser confundido com o código do APK 2.2.0 disponibilizado.

GitHub Pages publica apenas web/. O download usa caminho relativo para web/downloads/ODMANI-2.2.0-softui01-debug.apk. Metadados e checksum acompanham o arquivo.

A rotina de publicação valida o hash do pacote, limita os caminhos a site e documentação pública e confere o SHA-256 do APK antes de aplicar. Não modifica android/ nem credenciais.

O APK Debug é destinado a testes. Builds com certificado diferente não atualizam uma instalação anterior. Não desinstale a versão existente sem preservar seus dados.
