package br.com.lottan.nativeapp

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test

class NavigationTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test
    fun libraryAndOrganizationAreReachable() {
        compose.waitForIdle()
        if (compose.onAllNodesWithText("→").fetchSemanticsNodes().isNotEmpty())
            compose.onNodeWithText("→").performClick()
        compose.onNodeWithContentDescription("Biblioteca").performClick()
        compose.onNodeWithText("▥ Pastas e categorias").performClick()
        compose.onNodeWithText("Organizar PDFs").assertIsDisplayed()
    }
}
